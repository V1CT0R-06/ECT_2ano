//HIDE
//SHOWN
// Include this to supress output from all printfs!
#include <stdio.h>
#define puts(ARG) snprintf(NULL, 0, ARG "\n")
#define printf(ARGS...) snprintf(NULL, 0, ARGS)
#define fprintf(FP, ARGS...) snprintf(NULL, 0, ARGS)

