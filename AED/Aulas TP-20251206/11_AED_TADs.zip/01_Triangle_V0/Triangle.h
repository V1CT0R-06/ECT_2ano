//
// Algoritmos e Estruturas de Dados - 2025/2026 - 1o semestre
//
// J. Madeira - Outubro 2025
//

#ifndef _TRIANGLE_H_
#define _TRIANGLE_H_

// Triangle: the attibutes
struct Triangle {
  double side1;
  double side2;
  double side3;
};

#endif  // _TRIANGLE_H_
