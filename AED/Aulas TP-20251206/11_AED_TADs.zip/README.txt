
Simple representations and functions for the Triangle abstract type.

Compile with

gcc -Wall -Wextra testing_Triangle.c Triangle.c -o testing -lm

