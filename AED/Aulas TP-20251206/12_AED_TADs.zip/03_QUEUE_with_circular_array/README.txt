Simple examples --- Compile with

gcc -Wall -Wextra testing_IntegersQueue.c IntegersQueue.c -o testing_IntegersQueue

gcc -Wall -Wextra testing_PointersQueue.c PointersQueue.c -o testing_PointersQueue


TASK --- New example

Create a QUEUE of pointers to 2D points and test it !!
