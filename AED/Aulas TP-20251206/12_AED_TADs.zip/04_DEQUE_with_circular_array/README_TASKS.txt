
TASKS

1 - Specify the interface for the DEQUE abstract type - PointersDeque.h

2 - Use a CIRCULAR ARRAY for the internal representation - PointersDeque.c

3 - Implement the required functions

4 - Test your code with different application examples

SUGGESTION: use as a basis the QUEUE abstract type implemented with a CIRCULAR ARRAY